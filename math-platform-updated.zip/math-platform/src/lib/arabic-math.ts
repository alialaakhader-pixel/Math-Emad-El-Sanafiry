import { evaluate } from "mathjs";

const digitMap: Record<string, string> = { "٠":"0", "١":"1", "٢":"2", "٣":"3", "٤":"4", "٥":"5", "٦":"6", "٧":"7", "٨":"8", "٩":"9", "۰":"0", "۱":"1", "۲":"2", "۳":"3", "۴":"4", "۵":"5", "۶":"6", "۷":"7", "۸":"8", "۹":"9" };
export function normalizeArabicMath(input: string) {
  let s = input.replace(/[٠-٩۰-۹]/g, d => digitMap[d] ?? d).replace(/[٫،]/g, ".").replace(/×/g, "*").replace(/[÷]/g, "/").replace(/[−–]/g, "-").replace(/π/g, "pi").replace(/²/g, "^2").replace(/³/g, "^3").replace(/٪/g, "%");
  s = s.replace(/([0-9.)])\s*([سصع])/g, "$1*$2").replace(/([سصع])\s*([0-9(])/g, "$1*$2").replace(/([سصع])\s*([سصع])/g, "$1*$2");
  return s;
}
export function toArabicDigits(input: string) { return input.replace(/\d/g, d => "٠١٢٣٤٥٦٧٨٩"[Number(d)]); }
export function solveArabicEquation(raw: string) {
  const source = normalizeArabicMath(raw).replace(/\s/g, "");
  const pieces = source.split("=");
  if (pieces.length !== 2 || !pieces[0] || !pieces[1]) throw new Error("اكتب معادلة تحتوي على طرفين وبينهما علامة =.");
  const variable = (["س", "ص", "ع", "x", "y", "z"] as const).find(v => source.includes(v));
  if (!variable) throw new Error("اكتب مجهولاً واحداً من: س أو ص أو ع أو x أو y أو z.");
  if (["س", "ص", "ع"].some(v => v !== variable && source.includes(v)) || ["x", "y", "z"].some(v => v !== variable && source.includes(v))) throw new Error("حل مجهول واحد في كل مرة حالياً.");
  const left = pieces[0].replaceAll(variable, "x"), right = pieces[1].replaceAll(variable, "x");
  if (![left, right].every(part => /^[0-9x+\-*\/^().]+$/.test(part))) throw new Error("استخدم الأرقام والعمليات الأساسية فقط في المعادلات.");
  const f = (x: number) => Number(evaluate(`(${left})-(${right})`, { x }));
  const c = f(0), p = f(1), m = f(-1), q = f(2);
  if (![c,p,m,q].every(Number.isFinite)) throw new Error("تعذر فهم المعادلة. راجع الأقواس والعمليات.");
  const a = (p + m - 2*c) / 2, b = (p - m) / 2;
  const check = Math.abs((4*a + 2*b + c) - q);
  if (check > 1e-7 * Math.max(1, Math.abs(q))) throw new Error("هذه المعادلة ليست خطية أو تربيعية كثيرة الحدود؛ المحلل الحالي يدعم المعادلات الخطية والتربيعية.");
  const steps: string[] = [`ننقل الطرف الأيمن إلى الأيسر: ${variable === "س" ? "f(س)" : `f(${variable})`} = 0`, `الصيغة المبسطة: ${fmt(a)}${variable}² ${b < 0 ? "−" : "+"} ${fmt(Math.abs(b))}${variable} ${c < 0 ? "−" : "+"} ${fmt(Math.abs(c))} = 0`];
  if (Math.abs(a) < 1e-9) {
    if (Math.abs(b) < 1e-9) return { variable, kind: Math.abs(c) < 1e-9 ? "all" : "none", roots: [] as number[], steps: [...steps, Math.abs(c) < 1e-9 ? "المعادلة صحيحة لأي قيمة للمجهول." : "وصلنا إلى عبارة مستحيلة؛ لا يوجد حل."] };
    const root = -c/b;
    steps.push(`${fmt(b)}${variable} ${c < 0 ? "−" : "+"} ${fmt(Math.abs(c))} = 0`, `${fmt(b)}${variable} = ${fmt(-c)}`, `${variable} = ${fmt(root)}`);
    return { variable, kind: "linear", roots: [root], steps };
  }
  const delta = b*b - 4*a*c;
  steps.push(`المميز Δ = b² − ٤ac = ${fmt(delta)}`);
  if (delta < -1e-9) return { variable, kind: "none-real", roots: [] as number[], steps: [...steps, "المميز سالب؛ لا توجد حلول حقيقية."] };
  if (Math.abs(delta) <= 1e-9) { const root = -b/(2*a); steps.push(` ${variable} = −b ÷ (٢a) = ${fmt(root)}`); return { variable, kind: "double", roots: [root], steps }; }
  const roots = [(-b + Math.sqrt(delta))/(2*a), (-b - Math.sqrt(delta))/(2*a)].sort((u,v)=>u-v);
  steps.push(`باستخدام القانون العام: ${variable} = (−b ± √Δ) ÷ ٢a`, `${variable}₁ = ${fmt(roots[0])}`, `${variable}₂ = ${fmt(roots[1])}`);
  return { variable, kind: "quadratic", roots, steps };
}
function fmt(n: number) { return Number(n.toPrecision(8)).toString(); }
